<?php
mb_internal_encoding("utf8");
session_start();

try {
    $pdo = new PDO("mysql:dbname=manabiya_sakura; host=localhost;", "root", "");
} catch (PDOException $e) {
    die("<p>申し訳ございません。現在サーバーが混み合っており一時的にアクセスができません。<br>
    しばらくしてから再度ログインをしてください。</p>
    <a href='login.php'>ログイン画面へ</a>
    ");
}

/*
$stmt = $pdo->query("select * from login_mypage");

while ($_SESSION = $stmt->fetch()) {
    echo $_SESSION['name'];
    echo $_SESSION['mail'];
    echo $_SESSION['password'];
    echo $_SESSION['picture'];
    echo $_SESSION['comments'];
}
*/

$stmt = $pdo->prepare("select * from login_mypage where mail = ? and password = ? ");

$stmt->bindValue(1, $_POST['mail']);
$stmt->bindValue(2, $_POST['password']);

$stmt->execute();
$pdo = NULL;
?>

<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="utf-8">
    <title>マイページ</title>
    <link rel="stylesheet" type="text/css" href="mypage.css">
</head>

<body>
    <header>
        <img src="4eachblog_logo.jpg">
        <div class="logout"><a href="log_out.php">ログアウト</a></div>
    </header>

    <main>
        <div class="profile">
            <h2>会員情報</h2>
            <div class="profile_contents">
                <?php
                while ($row = $stmt->fetch()) {
                    $_SESSION = $row;
                    echo "<div class='hello'>" . $_SESSION['name'] . "さん こんにちは</div><br>";
                    echo "<div class='profile_main'>";
                    echo "<img src=image/" . $_SESSION['picture'] . "><br>";
                    echo "<div class='profile_right'>";
                    echo "氏名：" . $_SESSION['name'] . "<br><br>";
                    echo "メール：" . $_SESSION['mail'] . "<br><br>";
                    echo "パスワード：" . $_SESSION['password'] . "<br><br>";
                    echo "</div>";
                    echo "</div>";
                    echo "<div class='comments'>" . $_SESSION['comments'] . "</div>";
                }

                if (empty($_SESSION)) {
                    header("Location:login_error.php");
                    session_destroy();
                }

                ?>

            </div>
            <form action="mypage_hensyu.php" method="post">
                <input type="submit" class="modify_button" size="35" value="編集する">
            </form>

        </div>
    </main>

    <footer>
        ©2018 InterNous.inc. All rights reserved
    </footer>

</body>

</html>